﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Mvc;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OhmCalculator;
using OhmCalculator.Controllers;
using OhmCalculator.Models;

namespace OhmCalculator.Tests.Controllers
{
    [TestClass]
    public class HomeControllerTest
    {
        [TestMethod]
        public void Index()
        {
            // Arrange
            HomeController controller = new HomeController();

            // Act
            ViewResult result = controller.Index() as ViewResult;

            // Assert
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public void TestCalculateOhmValue()
        {
            //Arrange
            var controller = new HomeController();
            var ohmvalueModel = new OhmValueModel();
            ohmvalueModel.selectedcolorBandAModel = "2";
            ohmvalueModel.selectedcolorBandBModel = "2";
            ohmvalueModel.selectedcolorBandCModel = "2";
            ohmvalueModel.selectedcolorBandDModel = "5";
            //Insert
            ActionResult result = controller.CalculateOhmValue(ohmvalueModel);
            //Assert
            Assert.IsNotNull(result);
             
        }

        [TestMethod]
        public void TestCalculateOhmValueWithNegativeNultiplier()
        {
            //Arrange
            var controller = new HomeController();
            var ohmvalueModel = new OhmValueModel();
            ohmvalueModel.selectedcolorBandAModel = "2";
            ohmvalueModel.selectedcolorBandBModel = "2";
            ohmvalueModel.selectedcolorBandCModel = "-3";
            ohmvalueModel.selectedcolorBandDModel = "5";
            //Insert
            ActionResult result = controller.CalculateOhmValue(ohmvalueModel);
            //Assert
            Assert.IsNotNull(result);

        }
        [TestMethod]
        public void TestCalculateOhmValueWithZeroBandA()
        {
            //Arrange
            var controller = new HomeController();
            var ohmvalueModel = new OhmValueModel();
            ohmvalueModel.selectedcolorBandAModel = "0";
            ohmvalueModel.selectedcolorBandBModel = "2";
            ohmvalueModel.selectedcolorBandCModel = "-3";
            ohmvalueModel.selectedcolorBandDModel = "5";
            //Insert
            ActionResult result = controller.CalculateOhmValue(ohmvalueModel);
            //Assert
            Assert.IsNotNull(result);

        }
        [TestMethod]
        public void TestCalculateOhmValueWithdoubleBandD()
        {
            //Arrange
            var controller = new HomeController();
            var ohmvalueModel = new OhmValueModel();
            ohmvalueModel.selectedcolorBandAModel = "0";
            ohmvalueModel.selectedcolorBandBModel = "2";
            ohmvalueModel.selectedcolorBandCModel = "-3";
            ohmvalueModel.selectedcolorBandDModel = "0.25";
            //Insert
            ActionResult result = controller.CalculateOhmValue(ohmvalueModel);
            //Assert
            Assert.IsNotNull(result);

        }
        [TestMethod]
        public void TestCalculateOhmValueWithZeroBandAandB()
        {
            //Arrange
            var controller = new HomeController();
            var ohmvalueModel = new OhmValueModel();
            ohmvalueModel.selectedcolorBandAModel = "0";
            ohmvalueModel.selectedcolorBandBModel = "0";
            ohmvalueModel.selectedcolorBandCModel = "-3";
            ohmvalueModel.selectedcolorBandDModel = "0.25";
            //Insert
            ActionResult result = controller.CalculateOhmValue(ohmvalueModel);
            //Assert
            Assert.IsNotNull(result);

        }
        [TestMethod]
        public void TestCalculateOhmValueWithBandRangevalues()//check for int32 vs int 64 values
        {
            //Arrange
            var controller = new HomeController();
            var ohmvalueModel = new OhmValueModel();
            ohmvalueModel.selectedcolorBandAModel = "4";
            ohmvalueModel.selectedcolorBandBModel = "4";
            ohmvalueModel.selectedcolorBandCModel = "8";
            ohmvalueModel.selectedcolorBandDModel = "0.1";
            //Insert
            ActionResult result = controller.CalculateOhmValue(ohmvalueModel);
            //Assert
            Assert.IsNotNull(result);

        }
    }
}
