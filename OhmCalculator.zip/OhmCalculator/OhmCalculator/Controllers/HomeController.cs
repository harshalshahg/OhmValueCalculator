﻿using OhmCalculator.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;

namespace OhmCalculator.Controllers
{
    public class HomeController : Controller,IOhmValueCalculator//Interface Implemented
    {
       
        public ActionResult Index()
        {
            #region Filling/Mapping the model
            OhmValueModel ohm = new OhmValueModel(); // Creating the model object and filling in the model values
            ohm.colorModel = ohm.dict; // filling in the model values
            ohm.toleranceModel = ohm.dictTolerance;// filling in the model values
            ohm.multiplierModel = ohm.dictMultiplier;// filling in the model values 
            return View(ohm); 
            #endregion
        }

       
        [HttpPost]
        public ActionResult CalculateOhmValue(OhmValueModel f)
        {
            #region Mapping the values we get from the UI
            var listAValues = f.selectedcolorBandAModel;
            var listBValues = f.selectedcolorBandBModel;
            var listCValues = f.selectedcolorBandCModel;
            var listDValues = f.selectedcolorBandDModel;
            #endregion

            #region Calculating the Ohm Values
            if (listCValues != "-3" && listCValues != "-2" && listCValues != "-1" && listCValues != "8"&& listCValues != "9") // checking if the multiplier has negative power or positive 
            {
                double perctDiff;
                var calcWithMultiplier = CalculateOhmValue(listAValues, listBValues, listCValues, listDValues); // Calling the method to calculate the ohm value with multiplier
                perctDiff = ((double)calcWithMultiplier * (Convert.ToDouble(listDValues))) / 100; // Calcultaing the Tolerance
                var positiveRangeohm = calcWithMultiplier + perctDiff; //Adding the positive range Tolerance
                var negativeRangeohm = calcWithMultiplier - perctDiff; //Adding the negative range Tolerance
                f.negativeOhm = negativeRangeohm;//filling the calculated Ohm values in the model
                f.positiveOhm = positiveRangeohm;//filling the calculate Ohm values in the model
            }
           
            else
            {
                var calcWithMultiplier = CalculateOhmValueDecimal(listAValues, listBValues, listCValues, listDValues); // Calling the method to calculate the ohm value with multiplier
                double perctDiff;
                perctDiff = (calcWithMultiplier * (Convert.ToDouble(listDValues))) / 100; // Calcultaing the Tolerance
                var positiveRangeohm = calcWithMultiplier + perctDiff;//Adding the positive range Tolerance
                var negativeRangeohm = calcWithMultiplier - perctDiff;//Adding the negative range Tolerance
                f.negativeOhm = negativeRangeohm;//filling the calculated Ohm values in the model
                f.positiveOhm = positiveRangeohm;//filling the calculated Ohm values in the model
            } 
            
            return View(f);
            #endregion
        }
        #region Interface Method Implementation and Calculation of Ohm Value
        // I do not want to modify the return type of the Interface method in Question
        // I could had used Generic Type and used one method instead of two methods. For that i would had to modify the interface method return type change it to <T>
        //But since I was not sure if was allowed to do it i have written 2 seperate methods for calculating values for multiplier 
        // 1st method that return int(incase of multiplier 0 and greater than 0
        // 2nd method returns double in case of multiplier being less than 0    
        public int CalculateOhmValue(string bandAColor, string bandBColor, string bandCColor, string bandDColor)
        {                                                                                                      
            var multiplier = Math.Pow(10, Convert.ToDouble(bandCColor));                               //Using Pow function to  calculate multiplier value                                 
            StringBuilder s = new StringBuilder();                                                    // initializing string builder object                                   
            var significantVal = Convert.ToString(s.Append(bandAColor + bandBColor)).TrimStart('0');  //Trimming the leading zeros and appending band A and band B & appending the zeros        
            var multiplierWithouttolerance = significantVal!=""?(Convert.ToDouble(significantVal) * multiplier):0.0;               //multiplying by the multiplier
            return Convert.ToInt32(multiplierWithouttolerance);
        }

        public double CalculateOhmValueDecimal(string bandAColor, string bandBColor, string bandCColor, string bandDColor)
        {
            var multiplier = Math.Pow(10, Convert.ToDouble(bandCColor)); //Using Pow function to  calculate multiplier value  
            StringBuilder s = new StringBuilder();                        // initializing string builder object 
            var significantVal = Convert.ToString(s.Append(bandAColor + bandBColor)).TrimStart('0');//Trimming the leading zeros and appending band A and band B & appending the zeros  
            var multiplierWithouttolerance =significantVal!="" ? (Convert.ToDouble(significantVal) * multiplier):0.0; //multiplying by the multiplier
            return (multiplierWithouttolerance);
        }
        #endregion
    }
}