﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace OhmCalculator.Controllers
{
    public class OhmvalueController : Controller
    {
        
        // GET: Ohmvalue
        public ActionResult Index()
        {
            
            return View();
        }
    }
}