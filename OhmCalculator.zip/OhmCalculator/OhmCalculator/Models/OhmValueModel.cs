﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OhmCalculator.Models
{
    public class OhmValueModel
    {
        #region Variables
        public string selectedcolorBandAModel { get; set; }
        public string selectedcolorBandBModel { get; set; }
        public string selectedcolorBandCModel { get; set; }
        public string selectedcolorBandDModel { get; set; }
        public double positiveOhm { get; set; }//positive Ohm value
        public double negativeOhm { get; set; }//negative Ohm value 
        #endregion

        #region Dictionary Objects
        public IDictionary<string, string> colorModel = new Dictionary<string, string>();
        public IDictionary<string, string> toleranceModel = new Dictionary<string, string>();
        public IDictionary<string, string> multiplierModel = new Dictionary<string, string>();
        //Significant figure Band
        public IDictionary<string, string> dict = new Dictionary<string, string>() {
            { "Black", "0" },
            {"Brown", "1"},
            { "Red", "2" },
            {"Orange","3" },
            { "Yellow", "4" },
            { "Green", "5" },
            { "Blue", "6" },
            { "Violet", "7" },
            { "Gray", "8" },
           {"White", "9"}
            };
        //Tolerance Dictonary data
        public IDictionary<string, string> dictTolerance = new Dictionary<string, string>() {
            { "None", "20" },
            {"Silver", "10"},
            { "Gold", "5" },
            {"Brown","1" },
            { "Red", "2" },
            { "Yellow", "5" },
            { "Green", "0.5" },
            { "Blue", "0.25" },
            { "Violet", "0.1" },
             { "Gray", "0.05" }
            };
        //Multilier Dictionary Data
        public IDictionary<string, string> dictMultiplier = new Dictionary<string, string>() {
            { "Pink",   "-3" },
            { "Silver", "-2" },
            { "Gold",   "-1" },
            {"Black",   "0"},
            {"Brown",   "1" },
            { "Red",    "2" },
            { "Orange", "3" },
            { "Yellow", "4" },
            { "Green", "5" },
            { "Blue",  "6" },
            { "Violet","7" },
            { "Gray",  "8" },
            { "White", "9" }
            }; 
        #endregion
    }
   

}